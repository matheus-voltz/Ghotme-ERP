<div class="card">
  <div class="card-header">
    <h5 class="card-title">{{ $title }}</h5>
    <p class="card-subtitle">{{ $description }}</p>
  </div>
  <div class="card-body">{{ $content }}</div>
</div>
